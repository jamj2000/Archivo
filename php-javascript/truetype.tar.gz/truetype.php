<?php
// Crear una imagen de 300x100
$im = imagecreatetruecolor(300, 100);
$rojo = imagecolorallocate($im, 0xFF, 0x00, 0x00);
$negro = imagecolorallocate($im, 0x00, 0x00, 0x00);

// Hacer el fondo rojo
imagefilledrectangle($im, 0, 0, 299, 99, $rojo);

// Ruta a nuestro archivo de fuente ttf
$archivo_fuente = './fuente.ttf';

// Dibuja el texto 'Hola mundo' usando un tamaño de fuente de 13 y rotación 0 grados
// en la posición x,y = 105,55
imagefttext($im, 13, 0, 105, 55, $negro, $archivo_fuente, 'Hola mundo');

// Imprimir la imagen al navegador
header('Content-Type: image/png');
imagepng($im);
imagedestroy($im);
?>
 
