<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />   <!-- iso-8859-1, cp1252 -->

<form action="<?php $_SERVER[PHP_SELF] ?>" method="post" >
  <div style='width: 400px; background-color: lime '>
  <b>Usuario y clave</b><br>
  <input type='text' name='nombre' value="<?php $_REQUEST[nombre] ?>"/>
  <input type='password' name='clave' value="<?php $_REQUEST[clave] ?>" />
  </div>

  
  <div style='width: 400px; background-color: wheat'>
  <b>Estado civil</b><br>
  <input type='radio' name='estado' value='soltero' <?php  if ($_REQUEST['estado']=="soltero") echo 'checked' ?> />Soltero <br>
  <input type='radio' name='estado' value='casado'  <?php  if ($_REQUEST['estado']=="casado") echo 'checked' ?> />Casado <br>
  </div>
 
 <!--
  <div style='width: 400px; background-color: wheat'>
  <b>Estado civil</b><br>
  <select name="estado"> 
  <option value="soltero" <?php  if ($_REQUEST['estado']=="soltero") echo 'selected' ?>>Soltero</option> 
  <option value="casado" <?php  if ($_REQUEST['estado']=="casado") echo 'selected' ?>>Casado</option> 
  </select> 
  </div>
 --> 
 
  <div style='width: 400px; background-color: khaki '>
  <b>Aficiones</b><br>
  <input type='checkbox' name='deporte' value='deporte' <?php  if ($_REQUEST[deporte]) echo 'checked' ?>/>Hacer deporte <br>
  <input type='checkbox' name='musica' value='musica' <?php  if ($_REQUEST[musica]) echo 'checked' ?>/>Escuchar música <br>
  <input type='checkbox' name='otros' value='otros' <?php  if ($_REQUEST[otros]) echo 'checked' ?>/>Otras aficiones <br>
  </div>

  <div style='width: 400px; background-color: tan'> 
  <b>Observaciones</b><br>
  <textarea name='observaciones' cols='40' rows='5'><?php echo "$_REQUEST[observaciones]" ?></textarea> <br>
  </div>

  <div style='width: 400px; background-color: lightsalmon'>
  <b>Foto</b><br>
  <input type="file" name="foto"><br><br>
  </div>

  <input type="hidden" name="oculto" value="Algo oculto">

  <input type="button" value="Imprimir formulario" onclick='window.print()'> <!-- window.moveBy, window.moveTo, window.resizeBy, window.resizeTo -->
  <input type="reset" value="Resetear" />
  <input type="button" value="Borrar todo" onclick="location='<?php echo "http://$_SERVER[SERVER_NAME]$_SERVER[PHP_SELF]" ?>'" />
  <input type='submit' value='Enviar' />
  <input type="image" name="enviar" src="enviar.png" /> <!-- Para submit -->
</form>



<?php


if ($_REQUEST) {
    // Mostramos valores del formulario
    echo '<pre>';
    print_r($_REQUEST);
    echo '</pre>';
}



?>