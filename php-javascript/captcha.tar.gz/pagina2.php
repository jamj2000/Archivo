<?php
$ancho=100; 
$alto=30;
$imagen=imageCreate($ancho,$alto);

// Generamos fondo amarillo
$amarillo=ImageColorAllocate($imagen,255,255,0);
ImageFill($imagen,0,0,$amarillo);

// Generamos número aleatorio y guardamos en variable de sesión
$valoraleatorio=rand(100000,999999);
session_start();
$_SESSION['numeroaleatorio']=$valoraleatorio;

// Dibujamos número con color rojo
$rojo=ImageColorAllocate($imagen,255,0,0);
ImageString($imagen,5,25,5,$valoraleatorio,$rojo);

// Generamos 6 líneas para dificultar lectura a programas OCR
for($c=0;$c<=5;$c++)
{
  $x1=rand(0,$ancho);
  $y1=rand(0,$alto);
  $x2=rand(0,$ancho);
  $y2=rand(0,$alto);
  ImageLine($imagen,$x1,$y1,$x2,$y2,$rojo);
}
// Enviamos imagen al navegador
Header ("Content-type: image/jpeg");
ImageJPEG ($imagen);
ImageDestroy($imagen);
?> 