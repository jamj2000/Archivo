<html>
<head> <title>Guardar foto <?php echo $_FILES["foto"]["name"] ?></title> </head>
<body>
  <?php if (move_uploaded_file($_FILES["foto"]["tmp_name"], $_FILES["foto"]["name"]))  {?>
      <b>Foto subida</b><br>
      <img src="<?php echo $_FILES["foto"]["name"] ?>"><br>
      Nombre: <?php echo $_FILES["foto"]["name"] ?><br>
      Tipo: <?php echo $_FILES["foto"]["type"] ?><br>
      Bytes: <?php echo $_FILES["foto"]["size"] ?>
  <?php } else { ?>
      <b>Hubo un error al subir la foto.</b>
  <?php } ?>
</body>
</html>