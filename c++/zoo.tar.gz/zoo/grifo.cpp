#include <iostream>
#include "grifo"

using namespace std;

// Miembros estáticos
int Grifo::numGrifos = 0;
int Grifo::getNumGrifos () { return numGrifos; }

// Constructores y destructor
Grifo:: Grifo () { cout << "-> Grifo "; numGrifos++; }
Grifo::~Grifo () { cout << "<- Grifo "; numGrifos--; }
Grifo:: Grifo (string id, Sexo sexo, int edad) : Animal (id, sexo, edad) {  cout << "-> Grifo "; numGrifos++;  }

// Métodos redefinidos
void  Grifo::come     () { cout << "\nEl grifo desgarra y picotea la presa"; }
void  Grifo::se_mueve () { cout << "\nEl grifo corre y vuela"; }
 
