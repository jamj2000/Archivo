#include <iostream>
#include <string>
#include "leon"

using namespace std;

// Miembros estáticos
int Leon::numLeones = 0;
int Leon::getNumLeones () { return numLeones; }

// Constructores y destructor
Leon:: Leon () { cout << "-> León "; numLeones++; }
Leon::~Leon () { cout << "<- León "; numLeones--; }
Leon:: Leon (string id, Sexo sexo, int edad) : Animal (id, sexo, edad) {  cout << "-> León "; numLeones++; }

// Métodos redefinidos
void Leon::come     ()  { cout << "\nEl león desgarra la presa"; }
void Leon::se_mueve ()  { cout << "\nEl león corre"; }
void Leon::amamantar (int cachorros) { cout << "\nAmamanta a " << cachorros << " leones"; }

// Otros métodos 
void Leon::setRugido (string rugido) { this->rugido = rugido; } 
void Leon::ruge () { cout << endl << rugido << endl; }



