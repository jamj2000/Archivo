#include <iostream>
#include "ave"

using namespace std;

// Inicialización de miembros estáticos
int Ave::numAves = 0;
int Ave::getNumAves () { return numAves; }

// Definicion de métodos normales
Ave:: Ave () { cout << "-> Ave "; numAves++; }
Ave::~Ave () { cout << "<- Ave "; numAves--; }
//Ave:: Ave (string id, Sexo sexo, int edad) : Animal (id, sexo, edad) {  cout << "-> Ave "; numAves++; }

// Otros métodos
void Ave::setIncubacion (int diasIncubacion)  { this->diasIncubacion = diasIncubacion; } 
int  Ave::getIncubacion ()                    { return diasIncubacion; }                  



