#include <iostream>
#include <string>
#include <typeinfo> 
#include <cstdlib>

#include "leon"
#include "ave"
#include "grifo"

using namespace std;

void mostrar_nums (void);  // Muestra recuento de animales
void alojar (Animal &);    // Aloja animal en una zona


int main () {
  atexit (mostrar_nums); 
  mostrar_nums ();

  Leon leopoldo ("leopoldo", MACHO, 2);
  leopoldo.setEdad (4);  cout << leopoldo;  
  mostrar_nums();
  
  Aguila agueda ("Agueda rapaz", HEMBRA, 3);
  Grifo golfredo;
  mostrar_nums (); 

  alojar (leopoldo);
  alojar (agueda);
  alojar (golfredo);
 
  return 0;
}


void alojar (Animal &a){
    if (typeid(a)==typeid(Leon)){
      Leon &leon = dynamic_cast<Leon &> (a);
      leon.situar ("Sector 1");
      leon.setRugido ("GGGRRRRR...");  // Miembro de Leon
      leon.ruge ();                    // Miembro de Leon
      return;
    }
    if (typeid(a)==typeid(Aguila)) {
      Aguila &aguila = dynamic_cast<Aguila &> (a);
      aguila.situar ("Sector 2");
      aguila.setChillido ("CHHHIII...");  // Miembro de Aguila
      aguila.chilla ();                   // Miembro de Aguila
      return; 
    }
    if (typeid(a)==typeid(Grifo)) {
      Grifo &grifo = dynamic_cast<Grifo &> (a);
      grifo.situar ();
      return;
    }
}


void mostrar_nums (void){
  int animales =  Animal::getNumAnimales();
  int leones   =  Leon::getNumLeones();
  int aguilas  =  Aguila::getNumAguilas();

  cout << "\n** Animales = "  << animales;
  
  if (animales) {
    cout << "   (";

    if (leones) 
	cout << " Mamíferos = " << Mamifero::getNumMamiferos() << " ( Leones = "  << leones << " ) ";
    
    if (aguilas)
      cout << " Aves = " << Ave::getNumAves() << "  ( Aguilas = " << aguilas << " ) ";
    
    cout << " ) ";
  }  
  cout << endl;
}  



