#include <iostream>
#include "mamifero"

using namespace std;

// Miembros estáticos
int Mamifero::numMamiferos = 0;   // Inicialización
int Mamifero::getNumMamiferos () { return numMamiferos; }

// Definicion de métodos normales
Mamifero:: Mamifero () { cout << "-> Mamífero "; numMamiferos++; }
Mamifero::~Mamifero () { cout << "<- Mamífero "; numMamiferos--; }
//Mamifero:: Mamifero (string id, Sexo sexo, int edad) : Animal (id, sexo, edad) { cout << "-> Mamífero "; numMamiferos++; }

// Otros métodos
void Mamifero::setLactancia (int diasLactancia)  { this->diasLactancia = diasLactancia; } 
int  Mamifero::getLactancia ()                   { return diasLactancia; }


