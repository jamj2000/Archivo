#include <iostream>
#include "animal"

using namespace std;


// Miembros estáticos
int Animal::numAnimales = 0;
int Animal::getNumAnimales () { return numAnimales; }


// Constructores y destructor
Animal:: Animal () { cout << "\n-> Animal "; numAnimales++; }
Animal::~Animal () { cout << "<- Animal \n"; numAnimales--;}
Animal:: Animal (string id, Sexo sexo, int edad)  { numAnimales++;  this->id = id;  this->sexo = sexo;  this->edad = edad;}

// Métodos redefinidos
void   Animal::come      () {}
void   Animal::se_mueve  () {}
void   Animal::situar    (string  zona) { this->zona = zona; }
string Animal::situacion () { return zona; }


// Otros métodos
void Animal::setEdad (int edad)  { this->edad = edad;}
int  Animal::getEdad ()          { return edad; }
void Animal::setSexo (Sexo sexo) { this->sexo = sexo; }
Sexo Animal::getSexo ()          { this->sexo = sexo; }


// Sobrecarga de operador amigo <<
// No se indica el resolutor de ambito :: pues la funcion no es miembro de la clase, sólo amiga 
ostream& operator<< (ostream &out, const Animal &a) {
  string s;
  if (a.sexo) 
    if (a.sexo==MACHO)  s="Macho";  else  s="Hembra";
  else
    s = "Sin datos";

  out << endl << "DATOS DEL ANIMAL" << endl;
  out << "Nombre : " << a.id << endl;
  out << "Sexo   : " << s << endl;
  out << "Edad   : " << a.edad << endl;
  return out;
}

