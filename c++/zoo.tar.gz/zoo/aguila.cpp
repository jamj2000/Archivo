#include <iostream>
#include <string>
#include "aguila"

using namespace std;

// Miembros estáticos
int Aguila::numAguilas = 0;
int Aguila::getNumAguilas () { return numAguilas; }

// Constructores y destructor
Aguila:: Aguila () { cout << "-> Aguila "; numAguilas++; }
Aguila::~Aguila () { cout << "<- Aguila "; numAguilas--; }
Aguila:: Aguila (string id, Sexo sexo, int edad) : Animal (id, sexo, edad) {  cout << "-> Aguila "; numAguilas++;  }

// Métodos redefinidos
void Aguila::come     () { cout << "\nEl aguila picotea la presa"; }
void Aguila::se_mueve () { cout << "\nEl aguila planea"; }
void Aguila::incubar (int huevos) { cout << "\nEl aguila incuba " << huevos << " huevos"; }

// Otros métodos 
void Aguila::setChillido (string chillido) { this->chillido = chillido; } 
void Aguila::chilla () { cout << endl << chillido << endl; }



