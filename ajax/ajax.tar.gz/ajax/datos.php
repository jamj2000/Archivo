<?php
sleep (2);       // Simulamos un retardo de 2 seg.
header('Content-type: text/xml');
echo '<?xml version="1.0" encoding="UTF-8" ?>
<alumnos>
    <alumno>José Antonio</alumno>
    <alumno>Susana</alumno>
    <alumno>Ana</alumno>  
</alumnos>
';

?>