<?php
header('Content-type: text/xml');
echo '<?xml version="1.0" encoding="UTF-8" ?>
<mensaje>El tutor del curso ' .  $_GET[curso] . ' es ' . $_GET[tutor] . '</mensaje>';
?>