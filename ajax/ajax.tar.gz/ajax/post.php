<?php
header('Content-type: text/xml');
echo '<?xml version="1.0" encoding="UTF-8" ?>
<mensaje>El tutor del curso '.$_POST[curso].' es '.$_POST[tutor].'</mensaje>';
?>